'use client';

import React from 'react';

export default function BenchListPage() {
  return (
    <div className="container mx-auto p-8">
      <h1>Hello from Bench List Page!</h1>
    </div>
  );
}
