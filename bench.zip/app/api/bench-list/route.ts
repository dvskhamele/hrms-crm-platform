import { supabase } from '../../../lib/supabase';

export async function GET() {
  try {
    const { data, error } = await supabase
      .from('bench_list')
      .select('*');

    if (error) {
      console.error('Error fetching data:', error);
      return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }

    return new Response(JSON.stringify(data), { status: 200 });
  } catch (e: unknown) {
    console.error('Error processing request:', e);
    return new Response(JSON.stringify({ error: e.message }), { status: 500 });
  }
}