import { supabase } from '../../../lib/supabase';

export async function POST(request: Request) {
  try {
    const { company, role, location, salary, description } = await request.json();

    const { data, error } = await supabase
      .from('job_postings')
      .insert([
        { 
          company,
          role,
          location,
          salary,
          description
        }
      ])
      .select();

    if (error) {
      console.error('Error inserting data:', error);
      return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }

    return new Response(JSON.stringify({ message: 'Job posting created successfully', data }), { status: 200 });
  } catch (e: unknown) {
    console.error('Error processing request:', e);
    return new Response(JSON.stringify({ error: e.message }), { status: 500 });
  }
}
