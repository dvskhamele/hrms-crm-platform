'use client';

import React, { useState, useEffect } from 'react';

// Simplified profile data
const profilesData = [
  { 
    id: 'pranay-singhal', 
    name: 'Pranay Singhal', 
    title: 'Salesforce Developer', 
    experience: '5 years', 
    skills: ['Salesforce Developer'], 
    monthlyRate: 'On Request', 
    resumeLink: 'Profile on Request', 
    marketRate: '80,000' 
  },
  { 
    id: 'bhavesh-mistry', 
    name: 'Bhavesh Mistry', 
    title: 'Full Stack Designer', 
    experience: '4 years', 
    skills: ['Design', 'Bootstrap', 'Tailwind CSS', 'Material UI', 'Responsive Design', 'Animations', 'Figma', 'Photoshop', 'Adobe XD', 'React.js', 'Ruby on Rails', '.NET', 'Angular'], 
    monthlyRate: 'On Request', 
    resumeLink: 'Profile on Request', 
    marketRate: '75,000' 
  },
  { 
    id: 'sagar-shinde', 
    name: 'Sagar Shinde', 
    title: 'Senior Java Developer', 
    experience: '3 years', 
    skills: ['Core Java', 'Spring', 'Spring Boot', 'REST API', 'Spring Data JPA', 'Hibernate', 'JPA', 'MySQL', 'Kafka', 'Redis', 'AWS', 'Spring Security'], 
    monthlyRate: 'On Request', 
    resumeLink: 'Profile on Request', 
    marketRate: '70,000' 
  },
  { 
    id: 'abhishek-parihar', 
    name: 'Abhishek Parihar', 
    title: 'Full Stack Java/Python Developer', 
    experience: '6 years', 
    skills: ['Java', 'Spring', 'Spring Boot', 'REST API', 'Spring Data JPA', 'Hibernate', 'JPA', 'MySQL', 'Kafka', 'Redis', 'AWS', 'Spring Security', 'Python3', 'Django', 'Rest Framework', 'Git', 'Bit-bucket', 'SQLite', 'Slack', 'JIRA', 'Scrum', 'Kan-ban'], 
    monthlyRate: 'On Request', 
    resumeLink: 'https://docs.google.com/document/d/10Xpu8R1Zy7rfCIKRHIrzpDJKhoOfOTz8n084f5pK5BI/edit', 
    marketRate: '120,000' 
  },
  { 
    id: 'shikha-gupta', 
    name: 'Shikha Gupta', 
    title: 'Marketing Specialist', 
    experience: '2 years', 
    skills: ['Marketing'], 
    monthlyRate: 'On Request', 
    resumeLink: 'Profile on Request', 
    marketRate: '50,000' 
  },
  { 
    id: 'aishwarya-kulkarni', 
    name: 'Aishwarya Kulkarni', 
    title: 'UI/UX Designer', 
    experience: '5 years', 
    skills: ['Product Designer', 'UI/UX', 'Graphics Design', 'Figma', 'XD', 'Davanci Resolve', 'UIZARD', 'Zeplin', 'Photoshop', 'Illustrator', 'Canva'], 
    monthlyRate: 'On Request', 
    resumeLink: 'Profile on Request', 
    marketRate: '90,000' 
  }
];

// Popular skills for filtering
const popularSkills = ['React.js', 'Python', 'Java', 'AI/ML Engineer', '.NET'];

export default function BenchPage() {
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [selectedProfiles, setSelectedProfiles] = useState<string[]>([]);
  const [jobDescription, setJobDescription] = useState('');
  const [filteredProfiles, setFilteredProfiles] = useState(profilesData);
  const [pageSize, setPageSize] = useState(6);
  const [currentPage, setCurrentPage] = useState(1);

  // Filter profiles based on active filters and job description
  useEffect(() => {
    const filtered = profilesData.filter(profile => {
      // If no filters, show all profiles
      if (activeFilters.length === 0 && !jobDescription) {
        return true;
      }

      // Check if profile matches active filters
      const matchesFilters = activeFilters.every(filter => 
        profile.skills.some(skill => skill.toLowerCase().includes(filter.toLowerCase())) ||
        profile.title.toLowerCase().includes(filter.toLowerCase())
      );

      // Check if profile matches job description
      const matchesJD = jobDescription 
        ? profile.skills.some(skill => jobDescription.toLowerCase().includes(skill.toLowerCase())) ||
          jobDescription.toLowerCase().includes(profile.title.toLowerCase())
        : true;

      return matchesFilters && matchesJD;
    });

    setFilteredProfiles(filtered);
    setCurrentPage(1); // Reset to first page when filters change
  }, [activeFilters, jobDescription]);

  const toggleFilter = (filter: string) => {
    setActiveFilters(prev => 
      prev.includes(filter) 
        ? prev.filter(f => f !== filter) 
        : [...prev, filter]
    );
  };

  const toggleProfileSelection = (profileId: string) => {
    setSelectedProfiles(prev => 
      prev.includes(profileId) 
        ? prev.filter(id => id !== profileId) 
        : [...prev, profileId]
    );
  };

  const clearAllFilters = () => {
    setActiveFilters([]);
    setJobDescription('');
  };

  // Pagination
  const totalPages = Math.ceil(filteredProfiles.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const paginatedProfiles = filteredProfiles.slice(startIndex, startIndex + pageSize);

  return (
    <div className="container mx-auto p-4 bg-white">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-4">Signimus Talent Bench</h1>
        
        {/* Job Description Input */}
        <div className="mb-4">
          <textarea
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
            placeholder="Paste a job description here..."
            className="w-full p-2 border border-gray-300 rounded-lg"
            rows={3}
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mb-4">
          {activeFilters.map(filter => (
            <span 
              key={filter} 
              className="bg-indigo-600 text-white px-3 py-1 rounded-full text-sm flex items-center"
            >
              {filter}
              <button 
                onClick={() => toggleFilter(filter)}
                className="ml-2 text-white hover:text-gray-200"
              >
                &times;
              </button>
            </span>
          ))}
          
          {activeFilters.length > 0 && (
            <button 
              onClick={clearAllFilters}
              className="text-sm text-gray-500 hover:text-gray-700"
            >
              Clear all
            </button>
          )}
        </div>

        {/* Popular Skills */}
        <div className="flex flex-wrap gap-2 mb-4">
          {popularSkills.filter(skill => !activeFilters.includes(skill)).map(skill => (
            <button
              key={skill}
              onClick={() => toggleFilter(skill)}
              className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-gray-200"
            >
              {skill}
            </button>
          ))}
        </div>
      </div>

      {/* Profiles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {paginatedProfiles.map(profile => {
          const isSelected = selectedProfiles.includes(profile.id);
          
          return (
            <div 
              key={profile.id}
              className={`border rounded-lg p-4 cursor-pointer transition-all ${
                isSelected 
                  ? 'border-indigo-500 bg-indigo-50' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => toggleProfileSelection(profile.id)}
            >
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-lg font-semibold">{profile.name}</h3>
                {isSelected && (
                  <span className="bg-indigo-600 text-white text-xs px-2 py-1 rounded-full">
                    Selected
                  </span>
                )}
              </div>
              
              <p className="text-gray-600 mb-2">{profile.title}</p>
              
              <div className="flex items-center text-sm text-gray-500 mb-3">
                <span className="mr-3">{profile.experience} Experience</span>
                <span>₹{profile.monthlyRate !== 'On Request' ? profile.monthlyRate : 'On Request'}/month</span>
              </div>
              
              <div className="flex flex-wrap gap-1 mb-4">
                {profile.skills.slice(0, 5).map(skill => (
                  <span 
                    key={skill} 
                    className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded"
                  >
                    {skill}
                  </span>
                ))}
                {profile.skills.length > 5 && (
                  <span className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded">
                    +{profile.skills.length - 5} more
                  </span>
                )}
              </div>
              
              <div className="flex justify-between items-center">
                {profile.resumeLink && profile.resumeLink !== 'Profile on Request' ? (
                  <a 
                    href={profile.resumeLink} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                    onClick={(e) => e.stopPropagation()}
                  >
                    View Resume
                  </a>
                ) : (
                  <button 
                    className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                    onClick={(e) => {
                      e.stopPropagation();
                      // Handle profile request
                    }}
                  >
                    Profile on Request
                  </button>
                )}
                <span className="text-xs text-gray-500">
                  Market: ₹{profile.marketRate}/month
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center items-center mt-8 space-x-2">
          <button
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className="px-3 py-1 rounded border disabled:opacity-50"
          >
            Previous
          </button>
          
          {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
            <button
              key={page}
              onClick={() => setCurrentPage(page)}
              className={`px-3 py-1 rounded ${
                currentPage === page
                  ? 'bg-indigo-600 text-white'
                  : 'border hover:bg-gray-100'
              }`}
            >
              {page}
            </button>
          ))}
          
          <button
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="px-3 py-1 rounded border disabled:opacity-50"
          >
            Next
          </button>
        </div>
      )}

      {/* Selected Profiles Actions */}
      {selectedProfiles.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
          <div className="container mx-auto flex justify-between items-center">
            <p>{selectedProfiles.length} profile(s) selected</p>
            <div className="space-x-2">
              <button className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                Copy Selected Profiles
              </button>
              <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                Arrange Interview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}